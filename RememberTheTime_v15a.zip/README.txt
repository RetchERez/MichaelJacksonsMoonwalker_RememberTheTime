MICHAEL JACKSON'S MOONWALKER: REMEMBER THE TIME
v1.5a
By Retch

Three original Egyptian stages for Sega Genesis / Mega Drive, with custom scenery, enemies, encounters, music and Dance Magic animations

INCLUDED PATCHES

- Old Music: the pre-v1.3 arrangement
- New Music: the rebuilt approximately four-minute v1.3 arrangement
- FULL: the original campaign plus Egypt as Round 5 and Factory as Round 6
- DEMO: the three Egyptian stages, followed by a thank-you screen; press Start to play again
Both editions include Old Music and New Music choices with the v1.5a fixes
Choose one edition and music version, then apply only that patch to a clean original ROM

FEATURES

- EGYPT stages 5-1, 5-2 and 5-3, followed by the original Factory stages as Round 6
- Distinct pyramid, underground and palace routes connected by stairs and automatic lifts
- Black-and-gold architecture, golden doorways, blue decorations, torches and night views
- Eight children among twenty searchable objects per stage, with hidden cat surprises
- Palace Guards, Spear Throwers, wrapped Mummies and wandering wall-crawling Scarabs
- Three concluding encounters, ending with Anubis and jumping mummy guards
- Custom Dance Magic moves and Remember The Time in the FULL edition Options music selector
- Robot Michael in 5-3, with flight, lasers and hidden-child reveal

FEATURE DETAILS

5-1 follows broad horizontal pyramid routes with lower bypasses
5-2 descends through four underground tiers
5-3 connects a palace hub, upper apartments and two treasuries

Search golden doors, standing sarcophagi and ground coffers to rescue twenty-four children across Egypt
Selected containers hold surprise cats, so every search is worth investigating

Guards fight up close or throw spears; Mummies and Scarabs cause contact damage
Dance Magic features new poses for Michael and the Egyptian enemies, with directional variation

Catch the shooting star in the upper-right palace gallery to become Robot Michael
Fly, fire lasers and reveal which objects hide children, then return to normal to rescue them

The FULL game retains Rounds 1-4, inserts Egypt as Round 5 and moves Factory to Round 6 before the original finale

CHANGELOG

v1.5a - Arena and lift hotfix
- Moved the 5-2 end encounter to a flat crypt, preventing the stairway from trapping Michael against the locked arena boundary
- Fixed lift-driven camera scrolling moving hidden children away from their search objects, including while Michael is a robot
- Kept earlier scenery and other actors aligned during lift camera movement
- Retained both music arrangements and all earlier fixes in FULL and DEMO editions

v1.5 - Includes the v1.4 repairs
- Fixed the FULL game crash when searching the lower graveyard bushes in 3-1, allowing the hidden child to be rescued and the stage to be completed
- Restored the complete original search command table, including the missing graveyard bush entries
- Fixed yellow blocks and striped or mismatched enemy graphics after Mr. Big's challenge by keeping enemy, Anubis and dance graphics transfers within safe memory boundaries
- Fixed scenery remaining permanently black when Michael and Bubbles return after a 5-1 boss death
- Preserved the native recovery sequence before the custom entrance resumes
- Included all earlier stage, boss-floor, enemy defeat-art, sprite, music and intro repairs
- Bundled four clearly named patches in one ZIP: FULL and DEMO, each with Old Music and New Music

v1.4 - Earlier hardening revisions
- Introduced the graveyard search-table and graphics-transfer repairs included in v1.5
- Added Old Music and New Music release choices with the same gameplay and graphics

v1.3 - Music rebuild and gameplay repairs
- Rebuilt and extended Remember The Time into an approximately four-minute looping arrangement using native Moonwalker instruments
- Revised vocal melodies, the first-meeting response and changing chorus chords, with a dedicated Dance Magic chorus cue
- Softened the keyboard, balanced the backing and percussion and removed the added harmony horn
- Restored Who's Bad on the 5-1 portrait and the OOO shout during Michael's entrance pose
- Removed the extra entrance delay and empty music count-in so music and controls resume after the shout
- Fixed Down + Jump dropping Michael through the 5-3 boss floor into an inaccessible lower area
- Corrected guard, spear-thrower and mummy hurt and grounded defeat artwork that could make defeated enemies look alive

v1.2 - Three distinct stage layouts
- Redesigned 5-1 with broad horizontal pyramid routes, a shrine partition and lower exploration loops
- Redesigned 5-2 with four underground tiers, alternating descents and separate return galleries
- Redesigned 5-3 around a palace hub, upper apartments, treasury loops and the throne encounter
- Repositioned searches, enemies and complete decorations to suit the new routes
- Improved lift landing clearance and moved the robot-star activation to match the new palace upper floor
- Kept every room accessible by stairs, with lifts and Robot Michael providing optional routes

v1.1 - Michael dance sprite polish
- Redrew six custom dance poses to better match the original palette, proportions, height and shading
- Refined the hat, hands, shoes and limbs, aligned planted feet and removed clipping in both directions
- Preserved ordinary Michael artwork, collision, movement and physics

v1.0 - Initial release and rescue polish
- Added EGYPT 5-1, 5-2 and 5-3, with custom scenery, enemies, encounters and Remember The Time music
- Added custom Dance Magic for Michael and the Egyptian enemies, including directional variation
- Added searchable golden doors, standing sarcophagi and ground coffers, with eight children among twenty objects per stage
- Corrected rescued-child placement so planted feet meet the floor instead of floating in doorways
- Added cat surprises in selected containers: three in 5-1, two in 5-2 and three in 5-3
- Added the upper-right palace shooting star, robot flight, lasers and hidden-child reveal
- Added FULL campaign integration, EGYPT introductions, the Options music selection and a DEMO ending with Start replay

REQUIRED ORIGINAL ROM

Michael Jackson's Moonwalker - World REV00
Size: 524,288 bytes
CRC32: 6A70791B
SHA-1: 8960BAC2027CDEADB07E535A77597FB783E1433B
Use a clean binary ROM; REV01 and Rev A are not supported

PATCHED ROM INFORMATION

FULL - Old Music
Patch: RememberTheTime_FULL_v15a_Old_Music_REV00.bps
Size: 1,048,576 bytes
CRC32: 2BCDB8C0
SHA-1: 15FD3D35C55E00E1F3C24A2DD4AA18399A1900F3

FULL - New Music
Patch: RememberTheTime_FULL_v15a_New_Music_REV00.bps
Size: 1,048,576 bytes
CRC32: 5A223390
SHA-1: 3F32C85B193F6B7B5C53A77A1CD9C4080E12E781

DEMO - Old Music
Patch: RememberTheTime_DEMO_v15a_Old_Music_REV00.bps
Size: 1,048,576 bytes
CRC32: 53F0CD4B
SHA-1: 729F52EAC013C76DA63C9D02F73EE41A0B8D7AFF

DEMO - New Music
Patch: RememberTheTime_DEMO_v15a_New_Music_REV00.bps
Size: 1,048,576 bytes
CRC32: 17427C1A
SHA-1: 47DB1B7C17416C54AA9C10971DA45C472C17C62F

INSTALLATION

- Extract the ZIP and open a BPS-compatible patcher
- Select the clean World REV00 ROM and your preferred edition and music patch
- Save the result as a new ROM and check its CRC32 against the value above
- Start a new game instead of loading a save state from an older release or the other music version

Apply each patch directly to the clean original ROM, never over another patch
This download contains four BPS patches and this README; no game ROM is included

KNOWN ISSUES

- A reported 5-3 entry freeze remains unconfirmed and is not claimed fixed
- Broader reports of inaccurate hits and enemies catching on stairs remain open

This is the craziest thing I've ever AI-directed.
