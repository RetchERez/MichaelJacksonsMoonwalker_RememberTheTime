MICHAEL JACKSON'S MOONWALKER
Remember The Time
By Retch

Version 1.3
Sega Genesis / Mega Drive

ABOUT

Remember The Time expands Michael Jackson's Moonwalker with three new Egyptian stages, a Genesis music arrangement, new enemies and boss encounters, and custom Dance Magic animations

This release includes a full-game patch and an Egypt-only demo patch

CHANGELOG

v1.0 - Initial release
- Added EGYPT as three new stages, 5-1, 5-2 and 5-3, before the original Factory round
- Included separate FULL and Egypt-only DEMO patches, with a replayable thank-you ending for the demo
- Introduced Egyptian architecture, searchable golden doors, standing sarcophagi and ground coffers
- Added Palace Guards, Spear Throwers, Mummies, wandering Scarabs and hidden cat surprises
- Added mummy waves, a ranged-guard encounter and Anubis with jumping mummy escorts
- Added custom Dance Magic animations, the first Remember The Time arrangement and its Options music entry
- Added the palace shooting star and Robot Michael's flight, lasers and hidden-child reveal
- Final v1.0 polish grounded rescued children, expanded cat surprises and removed the extra entrance delay

v1.1 - Michael sprite polish
- Redrew Michael's six custom dance poses using the original player sprites as visual references
- Refined hat, hand and shoe proportions, slender limbs and suit shading
- Matched the original fixed player palette, upright scale and planted-foot position
- Kept ordinary Michael artwork, movement, collision and physics unchanged
- Retained the dance sequence and direction changes, with complete poses that fit their sprite cells

v1.2 - Three distinct stage layouts
- Redesigned 5-1 around horizontal exploration, entrance courts, an inner shrine and two lower loops
- Redesigned 5-2 as a four-tier underground descent with preparation rooms, crypts and eastern return passages
- Redesigned 5-3 around a palace hub, upper apartments, two treasury loops and an upper encounter gallery
- Repositioned searches, enemies and decorations around the new routes
- Improved lift landing clearance and kept stairs as routes to every room
- Adjusted the palace robot-star activation height to the redesigned upper floor
- Retained eight children and twenty searches per area, with three, two and three cat surprises respectively

v1.3 - Remember The Time music rebuild and targeted fixes
- Rebuilt and extended Remember The Time into an approximately four-minute looping Genesis arrangement
- Audited all original ROM music commands and their FM instruments to guide the new sound
- Used native Moonwalker FM instruments, DAC percussion and PSG parts for lead, bass, chords and rhythmic detail
- Corrected selected vocal melody phrases using available sheet-music references, including the first-meeting response
- Reworked the chorus keyboard with syncopated attacks and moving chord voicings instead of held two-note backing
- Replaced the harsh keyboard sound with a softer native instrument and raised the approved backing slightly in the final mix
- Removed the added harmonizing horn and retained restrained percussion, modulation and stereo placement
- Updated the chorus-based Dance Magic cue while preserving the game's dance timing markers
- Restored the original Who's Bad sample on the 5-1 Michael portrait, with the native 5-2 and 5-3 portrait cues unchanged
- Restored the original OOO shout during Michael's 5-1 entrance pose, followed by music and player control as the shout ends
- Removed the extra post-vocal delay and the song's empty count-in
- Made the 5-3 encounter floor solid against the reported Down + Jump drop-through softlock
- Corrected humanoid hurt and grounded defeat artwork mappings for Guards, Spear Throwers and Mummies


FEATURES

- Three original Egyptian stages numbered 5-1, 5-2 and 5-3
- New pyramid, underground and palace layouts
- Black-and-gold architecture with blue accents and Egyptian decorations
- Stairs, platforms, automatic lifts and connected rooms
- Eight children and twenty searchable objects in each Egyptian stage
- Searchable doors, standing sarcophagi and ground coffers
- Cat surprises hidden in selected sarcophagi
- Palace Guards, Spear Throwers, Mummies and wandering Scarabs
- Three end-of-stage encounters, including Anubis and jumping mummy guards
- Custom Dance Magic poses for Michael in the original game's sprite style
- Custom dance animations for the Egyptian enemies
- Remember The Time arranged for the Genesis sound system
- A dedicated chorus section for Dance Magic
- REMEMBER THE TIME added to the Options music selector
- Shooting-star robot transformation with flight and lasers in 5-3
- EGYPT stage introductions and a custom opening entrance
- Full-game and demo editions included

FEATURE DESCRIPTIONS

Egyptian stages
5-1 Pyramid Entrance follows a broad horizontal route through entrance courts, guard halls and an inner shrine
Explore two lower loops to bypass the shrine partition and search the burial chambers
5-2 Underground Pyramid descends through four tiers of archives, preparation rooms, embalming chambers and crypts
Alternating stairs and eastern return passages connect the rooms, with a four-stop lift providing a shortcut
5-3 Royal Palace connects a central hall to royal apartments above and two separate treasuries below
The upper central gallery hosts the final encounter, and the optional robot star waits in the upper-right wing
Black-and-gold masonry, golden doors and floors, blue decorations, torches, reliefs and selected night views give the stages their Egyptian setting
Every room can be reached by stairs, with automatic lifts providing alternate connections

Search and rescue
Each Egyptian stage hides eight children among twenty searchable objects, for twenty-four rescues across the three stages
Search doors, standing sarcophagi, ground coffers and selected wall decorations
Some sarcophagi reveal cats instead of children: three cat surprises in 5-1, two in 5-2 and three in 5-3

Enemies and encounters
Palace Guards fight at close range, while Spear Throwers attack from a distance
Mummies advance with their arms out and inflict contact damage
Scarabs crawl across walls and floors, changing direction and pausing within their rooms
The concluding encounters feature mummy waves in 5-1, stronger ranged guards in 5-2, and Anubis with jumping mummy guards in 5-3
Anubis wears a jackal headdress and can call one replacement pair of mummy guards

Dance Magic and music
Michael performs new Egyptian-inspired dance poses with a varied sequence and direction changes
The drawings use the original game's player palette, upright height and foot placement
The Egyptian enemies perform custom dance poses with directional variation
Mummies dance with outstretched arms, Scarabs turn in rhythm, and Anubis has his own dance poses
Remember The Time is rebuilt as an approximately four-minute looping Genesis arrangement, with a selected chorus section accompanying Dance Magic
Native Moonwalker instruments provide the lead, bass and softer chord backing, supported by restrained DAC drums and PSG detail
The chorus uses syncopated keyboard rhythm and changing chord voicings, with selected vocal phrases corrected from available notation
This is an instrumental game arrangement, without sampled album vocals or the added harmonizing horn
The 5-1 Michael portrait plays the original Who's Bad vocal before the stage begins
The 5-2 and 5-3 portraits retain their native vocal cues
Michael then enters 5-1 and performs his entrance pose with the original OOO shout
Music and player control begin as that shout finishes, without an extra one-second wait or an empty musical count-in
In the full edition's Options screen, select REMEMBER THE TIME with Left or Right and press Start to play it

Robot transformation
Catch the shooting star in the upper-right palace gallery of 5-3 to transform into Robot Michael
Fly through the area, attack enemies with lasers and reveal which searchable objects contain children
Return to normal form to rescue the children

EDITIONS

FULL
Patch: Remember_The_Time_FULL_v1_3_REV00.bps
Play the original Club, Street, Woods and Cavern rounds, followed by EGYPT as the new Round 5
The original Factory becomes Round 6, followed by the original finale

Stage order:
Original Rounds 1-4 -> EGYPT 5-1, 5-2, 5-3 -> Factory 6-1, 6-2, 6-3 -> original finale

DEMO
Patch: Remember_The_Time_DEMO_v1_3_REV00.bps
Start directly in EGYPT 5-1 and play all three Egyptian stages
After 5-3, the ending displays THANKS FOR PLAYING! and TRY THE FULL ROMHACK!
The screen stays until you release Start and press it again to begin a fresh demo
The demo skips the normal title and Options menus

Stage order:
EGYPT 5-1 -> EGYPT 5-2 -> EGYPT 5-3 -> thank-you screen

REQUIRED ORIGINAL ROM

Game: Michael Jackson's Moonwalker
Region and revision: World REV00
Common filename: Michael Jackson's Moonwalker (W) (REV 00) [!].bin
Size: 524,288 bytes
CRC32: 6A70791B
SHA-1: 8960BAC2027CDEADB07E535A77597FB783E1433B

Use a clean, unmodified binary ROM
REV01 and Rev A are not supported
No game ROM is included

PATCHED ROM INFORMATION

FULL
Size: 1,048,576 bytes / 1 MiB
CRC32: 66A21C72
SHA-1: A9B08DF2FF22BD619B00F8B0AAFF28BB9668BFA1

DEMO
Size: 1,048,576 bytes / 1 MiB
CRC32: 660DCA3C
SHA-1: 0A0334DD2561E0606D32FD4BF73AE89C86704C45

PATCH FILE INFORMATION

Format: BPS
FULL patch SHA-256: D217D520EB098F396B858E042D8FBFC3A8B2BF11C1FA671617C6A3025443283A
DEMO patch SHA-256: 1A8F89DD0533DBAF504C5ACD31585A300350C8936395E5DD339E505A3554322C

HOW TO APPLY

- Extract this ZIP
- Open a BPS-compatible patcher
- Select your clean World REV00 ROM as the source
- Choose the FULL or DEMO BPS patch
- Save the result as a new ROM file
- Check the output CRC32 against the corresponding value above
- Load the patched ROM in a Genesis / Mega Drive emulator
- Start a new game instead of loading a save state from an older build

Apply each patch directly to the clean original ROM
To create both editions, apply each patch separately to the same clean source
Do not apply one edition over the other or over an earlier hack

KNOWN ISSUES

Intermittent black-screen retries during end encounters and a 5-3 entry freeze were reported in v1.2
These have not been reproduced locally and are not confirmed fixed in v1.3
Broader reports about hit detection and enemies catching on stairs also remain under investigation
The targeted floor and defeat-art corrections above do not resolve every reported issue

ARCHIVE CONTENTS

Remember_The_Time_FULL_v1_3_REV00.bps
Remember_The_Time_DEMO_v1_3_REV00.bps
README.txt
