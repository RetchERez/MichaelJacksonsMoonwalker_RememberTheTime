MICHAEL JACKSON'S MOONWALKER
Remember The Time
By Retch

Version 1.2
Sega Genesis / Mega Drive

ABOUT

Remember The Time expands Michael Jackson's Moonwalker with three new Egyptian stages, a Genesis music arrangement, new enemies and boss encounters, and custom Dance Magic animations

This release includes a full-game patch and an Egypt-only demo patch

NEW IN VERSION 1.2

- Redesigned routes for all three Egyptian stages
- Horizontal exploration loops in 5-1, a four-tier descent in 5-2 and a palace hub with treasury loops in 5-3
- Repositioned searches and enemies around the new rooms and connections
- Complete decoration placement and improved lift landing clearance
- Original Michael sprites and the custom Dance Magic poses from version 1.1 retained

FEATURES

- Three original Egyptian stages numbered 5-1, 5-2 and 5-3
- New pyramid, underground and palace layouts
- Black-and-gold architecture with blue accents and Egyptian decorations
- Stairs, platforms, automatic lifts and connected rooms
- Eight children and twenty searchable objects in each Egyptian stage
- Searchable doors, standing sarcophagi and ground coffers
- Cat surprises hidden in selected sarcophagi
- Palace Guards, Spear Throwers, Mummies and wandering Scarabs
- Three end-of-stage encounters, including Anubis and jumping mummy guards
- Custom Dance Magic poses for Michael in the original game's sprite style
- Custom dance animations for the Egyptian enemies
- Remember The Time arranged for the Genesis sound system
- A dedicated chorus section for Dance Magic
- REMEMBER THE TIME added to the Options music selector
- Shooting-star robot transformation with flight and lasers in 5-3
- EGYPT stage introductions and a custom opening entrance
- Full-game and demo editions included

FEATURE DESCRIPTIONS

Egyptian stages
5-1 Pyramid Entrance follows a broad horizontal route through entrance courts, guard halls and an inner shrine
Explore two lower loops to bypass the shrine partition and search the burial chambers
5-2 Underground Pyramid descends through four tiers of archives, preparation rooms, embalming chambers and crypts
Alternating stairs and eastern return passages connect the rooms, with a four-stop lift providing a shortcut
5-3 Royal Palace connects a central hall to royal apartments above and two separate treasuries below
The upper central gallery hosts the final encounter, and the optional robot star waits in the upper-right wing
Black-and-gold masonry, golden doors and floors, blue decorations, torches, reliefs and selected night views give the stages their Egyptian setting
Every room can be reached by stairs, with automatic lifts providing alternate connections

Search and rescue
Each Egyptian stage hides eight children among twenty searchable objects, for twenty-four rescues across the three stages
Search doors, standing sarcophagi, ground coffers and selected wall decorations
Some sarcophagi reveal cats instead of children: three cat surprises in 5-1, two in 5-2 and three in 5-3

Enemies and encounters
Palace Guards fight at close range, while Spear Throwers attack from a distance
Mummies advance with their arms out and inflict contact damage
Scarabs crawl across walls and floors, changing direction and pausing within their rooms
The concluding encounters feature mummy waves in 5-1, stronger ranged guards in 5-2, and Anubis with jumping mummy guards in 5-3
Anubis wears a jackal headdress and can call one replacement pair of mummy guards

Dance Magic and music
Michael performs new Egyptian-inspired dance poses with a varied sequence and direction changes
The drawings use the original game's player palette, upright height and foot placement
The Egyptian enemies perform custom dance poses with directional variation
Mummies dance with outstretched arms, Scarabs turn in rhythm, and Anubis has his own dance poses
Remember The Time is a Genesis arrangement of the song, with a selected chorus section accompanying Dance Magic
In the full edition's Options screen, select REMEMBER THE TIME with Left or Right and press Start to play it

Robot transformation
Catch the shooting star in the upper-right palace gallery of 5-3 to transform into Robot Michael
Fly through the area, attack enemies with lasers and reveal which searchable objects contain children
Return to normal form to rescue the children

EDITIONS

FULL
Patch: Remember_The_Time_FULL_v1_2_REV00.bps
Play the original Club, Street, Woods and Cavern rounds, followed by EGYPT as the new Round 5
The original Factory becomes Round 6, followed by the original finale

Stage order:
Original Rounds 1-4 -> EGYPT 5-1, 5-2, 5-3 -> Factory 6-1, 6-2, 6-3 -> original finale

DEMO
Patch: Remember_The_Time_DEMO_v1_2_REV00.bps
Start directly in EGYPT 5-1 and play all three Egyptian stages
After 5-3, the ending displays THANKS FOR PLAYING! and TRY THE FULL ROMHACK!
The screen stays until you release Start and press it again to begin a fresh demo
The demo skips the normal title and Options menus

Stage order:
EGYPT 5-1 -> EGYPT 5-2 -> EGYPT 5-3 -> thank-you screen

REQUIRED ORIGINAL ROM

Game: Michael Jackson's Moonwalker
Region and revision: World REV00
Common filename: Michael Jackson's Moonwalker (W) (REV 00) [!].bin
Size: 524,288 bytes
CRC32: 6A70791B

Use a clean, unmodified binary ROM
REV01 and Rev A are not supported
No game ROM is included

PATCHED ROM INFORMATION

FULL
Size: 1,048,576 bytes / 1 MiB
CRC32: CCC00087

DEMO
Size: 1,048,576 bytes / 1 MiB
CRC32: 30CF6DEF

PATCH FILE INFORMATION

Format: BPS
FULL patch CRC32: 2144DF1C
DEMO patch CRC32: 2144DF1C

HOW TO APPLY

- Extract this ZIP
- Open a BPS-compatible patcher
- Select your clean World REV00 ROM as the source
- Choose the FULL or DEMO BPS patch
- Save the result as a new ROM file
- Check the output CRC32 against the corresponding value above
- Load the patched ROM in a Genesis / Mega Drive emulator
- Start a new game instead of loading a save state from an older build

Apply each patch directly to the clean original ROM
To create both editions, apply each patch separately to the same clean source
Do not apply one edition over the other or over an earlier hack

ARCHIVE CONTENTS

Remember_The_Time_FULL_v1_2_REV00.bps
Remember_The_Time_DEMO_v1_2_REV00.bps
README.txt
